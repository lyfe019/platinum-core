<?php

declare(strict_types=1);

namespace Platinum\Core\Http;

use Platinum\Core\Http\Middleware\MiddlewarePipeline;
use Platinum\Core\Http\Middleware\MiddlewareStack;
use RuntimeException;

/**
 * Framework API Kernel.
 *
 * Entry point for every HTTP request handled by the framework.
 */
final class ApiKernel
{
    /**
     * Framework router.
     */
    private Router $router;

    /**
     * Middleware stack.
     */
    private MiddlewareStack $middleware;

    /**
     * Middleware pipeline.
     */
    private MiddlewarePipeline $pipeline;

    /**
     * Create a new API kernel.
     */
    public function __construct(
        ?Router $router = null,
        ?MiddlewareStack $middleware = null,
        ?MiddlewarePipeline $pipeline = null,
    ) {
        $this->router = $router ?? new Router();

        $this->middleware = $middleware ?? new MiddlewareStack();

        $this->pipeline = $pipeline ?? new MiddlewarePipeline();
    }

    /**
     * Return the router.
     */
    public function router(): Router
    {
        return $this->router;
    }

    /**
     * Return the middleware stack.
     */
    public function middleware(): MiddlewareStack
    {
        return $this->middleware;
    }

    /**
     * Handle an incoming request.
     */
    public function handle(
        Request $request
    ): Response {

        $route = $this->router->match(
            $request->method(),
            $request->uri(),
        );

        if ($route === null) {

            return Response::json(
                [
                    'message' => 'Route not found.',
                ],
                404,
            );
        }

        $controller = $route->action();

        if (! class_exists($controller)) {

            throw new RuntimeException(
                sprintf(
                    'Controller [%s] does not exist.',
                    $controller,
                )
            );
        }

        $instance = new $controller();

        if (! is_callable($instance)) {

            throw new RuntimeException(
                sprintf(
                    'Controller [%s] is not invokable.',
                    $controller,
                )
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Execute middleware pipeline
        |--------------------------------------------------------------------------
        */

        return $this->pipeline->process(
            $request,
            $this->middleware->all(),
            fn (Request $request): Response => $instance($request),
        );
    }
}